package com.payroll.microservices.EmployeePayrollService;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//@FeignClient(name="Role-Service",url="localhost:8101")
//@FeignClient(name="Role-Service")
@FeignClient(name="zuul-edge-server")
@RibbonClient(name="Role-Service")
public interface RoleService {
	
	@GetMapping("/role-service/role/{roleName}")
	public EmployeePayroll getRoleByName(@PathVariable("roleName") String roleName);

}
