package com.payroll.microservices.EmployeePayrollService;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


//@FeignClient(name="Employee-Service",url="localhost:8080")
//@FeignClient(name="Employee-Service")
@FeignClient(name="zuul-edge-server")
@RibbonClient(name="Employee-Service")
public interface EmployeeService {
	
	@GetMapping("/employee-service/employee/{empId}")
	public EmployeePayroll getEmployeeDetails(@PathVariable("empId") Long empId);

}
