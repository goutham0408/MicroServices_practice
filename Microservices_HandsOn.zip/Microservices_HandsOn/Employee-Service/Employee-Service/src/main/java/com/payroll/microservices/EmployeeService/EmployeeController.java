package com.payroll.microservices.EmployeeService;

import java.util.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


@RestController
@EnableHystrix
public class EmployeeController {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Autowired
	EmployeeConfiguration employeeConfiguration;
	
	@Autowired
	Environment environment;
	
	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	@GetMapping("/employee/{empId}")
	public Employee getEmployeeDetails(@PathVariable Long empId) {
		
		logger.info("Inside getEmployeeDetails");
		
		//return new Employee("Goutham","ggg",101L,new Date());
		Employee employee = employeeRepository.findOne(empId);
		employee.setPort(Integer.parseInt(environment.getProperty("local.server.port")));
		return employee;
		
	}
	
	@GetMapping("/employee/fault-tolerance")
	@HystrixCommand(fallbackMethod="fallBackEmployeeDetails")
	public Employee getEmployeeDetailsFaultTolerance() {
			throw new RuntimeException();
	}
	
	public Employee fallBackEmployeeDetails() {
		//return new Employee("firstName", "lastName", 101L, new Date());
		return new Employee(employeeConfiguration.getDefaultFirstName() , employeeConfiguration.getDefaultLastName(), 101L, new Date());
	}
}
