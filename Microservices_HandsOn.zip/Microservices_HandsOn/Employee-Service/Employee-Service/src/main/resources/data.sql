insert into employee(emp_id,first_name,last_name,date_of_joining,port) values(1000,'Goutham','p',sysdate(),0);
insert into employee(emp_id,first_name,last_name,date_of_joining,port) values(1001,'Kalyan','p',sysdate(),0);
insert into employee(emp_id,first_name,last_name,date_of_joining,port) values(1002,'Dhoni','MS',sysdate(),0);