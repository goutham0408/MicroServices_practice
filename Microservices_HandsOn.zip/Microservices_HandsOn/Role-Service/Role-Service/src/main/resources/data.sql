insert into employee_role(role_id,role_name,description) values (0108,'Batsmen','cricket')
insert into employee_role(role_id,role_name,description) values (0408,'Coach','badminton')
insert into employee_role(role_id,role_name,description) values (0008,'spiker','volleyball')